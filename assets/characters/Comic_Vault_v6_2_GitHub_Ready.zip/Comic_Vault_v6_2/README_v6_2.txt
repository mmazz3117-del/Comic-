COMIC VAULT v6.2

GitHub deployment structure:

index.html
assets/
  characters/
    adam-strange.webp
    alfred-pennyworth.webp
    amanda-waller.webp
    aqualad.webp
    aquaman.webp
    ares.webp
    artemis-of-bana-mighdall.webp
    atrocitus.webp
    bane.webp
    batgirl.webp
    batman.webp
    batwoman.webp
    beast-boy.webp
    bizarro.webp
    black-adam.webp
    black-canary.webp
    black-manta.webp
    black-mask.webp
    blue-beetle.webp
    booster-gold.webp
    brainiac.webp
    captain-boomerang.webp
    captain-cold.webp

Upload index.html and preserve the assets/characters folder path exactly.
The app will load WebP first and automatically retry PNG for future characters.
